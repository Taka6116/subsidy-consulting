/**
 * AWS Lambda エントリポイント: jGrants 検知 → 記事生成 → ISR パージ を 1 本で実行する。
 *
 * トリガー: EventBridge Scheduler（15 分間隔など）
 * ランタイム: Node.js 20.x
 * 依存: pg のみ（AWS SDK は不要、Bedrock は Vercel API 側で実行）
 *
 * 処理:
 *  1. jGrants API を叩いて新規 / 継続中の補助金を取得
 *  2. RDS に UPSERT（新規行に対しては content_jobs に pending を積む）
 *  3. content_jobs.article.pending を 5 件まで選び、Vercel の POST /api/articles/generate を叩く
 *  4. 生成された slug を束ねて POST /api/revalidate で ISR を即時パージ
 *  5. sync_logs にサマリを残す
 *
 * 必要な環境変数（Lambda の環境変数 or Secrets Manager 経由で注入）:
 *   DATABASE_URL            Amazon RDS PostgreSQL の接続文字列
 *   VERCEL_APP_URL          例: https://nts-gate-lp.vercel.app （末尾スラッシュなし）
 *   ARTICLE_GENERATE_TOKEN  POST /api/articles/generate 認証用
 *   REVALIDATE_SECRET       POST /api/revalidate 認証用
 *   DRAIN_LIMIT             1 回で消化する最大件数（後方互換。未指定時は各 DRAIN_LIMIT_* のフォールバック）
 *   DRAIN_LIMIT_ARTICLE     記事生成の 1 回あたり上限（デフォルト 1）
 *   DRAIN_LIMIT_LP          LP 生成の 1 回あたり上限（デフォルト 1）
 *   DRAIN_LIMIT_VIDEO       動画生成の 1 回あたり上限（デフォルト 0 = Vercel 上の FFmpeg 生成は停止）
 *   ENABLE_VERCEL_VIDEO     "true" のときのみ /api/videos/generate を呼ぶ（デフォルト false）
 *   SYNC_USER_AGENT         jGrants へ送る User-Agent（礼儀作法用、例: "nts-lambda/1.0 (contact: ops@...)"）
 */
import pg from "pg";
import { randomUUID } from "node:crypto";

const LOG = "[article-pipeline]";
const JGRANTS_BASE = "https://api.jgrants-portal.go.jp/exp/v1/public";

// -----------------------------------------------------------------------------
// 省庁クローラー設定
// 各ソースから最新 MINISTRY_FETCH_LIMIT 件を取得し、以降は差分のみ追記する。
// -----------------------------------------------------------------------------
const MINISTRY_FETCH_LIMIT = 20; // 初回・通常実行ともに最新 20 件を対象とする

/** 補助金・公募関連のキーワード（タイトルフィルタ用） */
const SUBSIDY_KEYWORDS = [
  "補助金", "補助事業", "助成金", "支援事業",
  "公募", "募集開始", "交付申請", "申請受付",
];

function isSubsidyRelated(title) {
  return SUBSIDY_KEYWORDS.some((kw) => title.includes(kw));
}

/**
 * RSS/Atom フィードを fetch して { title, link, pubDate } の配列を返す。
 * 外部ライブラリ不使用・正規表現のみで処理する。
 */
async function fetchRssItems(url, userAgent) {
  const res = await fetch(url, {
    headers: { Accept: "application/rss+xml, application/atom+xml, text/xml, */*", "User-Agent": userAgent },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`RSS fetch error: ${res.status} ${url}`);
  const xml = await res.text();

  const items = [];

  // ----- Atom <entry> -----
  const entryRegex = /<entry[^>]*>([\s\S]*?)<\/entry>/g;
  let m;
  while ((m = entryRegex.exec(xml)) !== null) {
    const block = m[1];
    const title = extractXmlText(block, "title");
    const link =
      block.match(/<link[^>]+href="([^"]+)"/)?.[1] ??
      extractXmlText(block, "link") ?? "";
    const pubDate = extractXmlText(block, "updated") ?? extractXmlText(block, "published") ?? "";
    if (title) items.push({ title, link, pubDate });
  }

  // ----- RSS <item> -----
  const itemRegex = /<item[^>]*>([\s\S]*?)<\/item>/g;
  while ((m = itemRegex.exec(xml)) !== null) {
    const block = m[1];
    const title = extractXmlText(block, "title");
    const link = extractXmlText(block, "link") ?? "";
    const pubDate = extractXmlText(block, "pubDate") ?? "";
    if (title) items.push({ title, link, pubDate });
  }

  return items.slice(0, MINISTRY_FETCH_LIMIT);
}

/** XML タグの中身を取り出す（CDATA 対応） */
function extractXmlText(block, tag) {
  const m = block.match(
    new RegExp(`<${tag}[^>]*>(?:<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>|([\\s\\S]*?))<\\/${tag}>`, "i"),
  );
  if (!m) return null;
  return (m[1] ?? m[2] ?? "").trim() || null;
}

/**
 * HTMLページから補助金らしいリンクを最大 MINISTRY_FETCH_LIMIT 件抽出する。
 * 農水省・国交省など RSS を持たない省庁向け。
 */
async function fetchHtmlLinks(pageUrl, linkBaseUrl, userAgent) {
  const res = await fetch(pageUrl, {
    headers: { "User-Agent": userAgent },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`HTML fetch error: ${res.status} ${pageUrl}`);
  const html = await res.text();

  const anchors = [];
  const aRegex = /<a\s[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = aRegex.exec(html)) !== null) {
    const href = m[1].trim();
    const rawText = m[2].replace(/<[^>]+>/g, "").trim();
    if (!isSubsidyRelated(rawText)) continue;
    // 絶対 URL に変換
    let link = href;
    if (href.startsWith("/")) link = `${linkBaseUrl}${href}`;
    else if (!href.startsWith("http")) continue;
    anchors.push({ title: rawText, link, pubDate: "" });
    if (anchors.length >= MINISTRY_FETCH_LIMIT) break;
  }
  return anchors;
}

/** 省庁データを SubsidyGrant に UPSERT する（externalId = "ministry-{source}-{url}"） */
async function upsertMinistryGrant(client, { title, link, pubDate, source }) {
  // link が空の場合はスキップ
  if (!link) return null;

  const externalId = `ministry-${source}-${link}`;
  const deadlineRaw = pubDate ? new Date(pubDate) : null;
  const deadline = deadlineRaw && !Number.isNaN(deadlineRaw.getTime()) ? deadlineRaw : null;

  const query = `
    INSERT INTO "SubsidyGrant" (
      id, "externalId", name, description,
      "maxAmountLabel", "deadlineLabel",
      deadline, status, source,
      "targetIndustries", "targetIndustryNote", prefecture,
      "rawPayload", "updatedAt", "syncedAt"
    )
    VALUES (
      $1, $2, $3, NULL,
      NULL, $4,
      $5, 'open', $6,
      '{}', NULL, NULL,
      $7::jsonb, NOW(), NOW()
    )
    ON CONFLICT ("externalId") DO UPDATE SET
      name            = EXCLUDED.name,
      "deadlineLabel" = EXCLUDED."deadlineLabel",
      deadline        = EXCLUDED.deadline,
      "rawPayload"    = EXCLUDED."rawPayload",
      status          = 'open',
      "updatedAt"     = NOW()
    RETURNING id, (xmax = 0) AS is_new
  `;

  const values = [
    randomUUID(),
    externalId,
    title.slice(0, 400),
    pubDate || null,
    deadline,
    source,
    JSON.stringify({ source, url: link, pubDate, fetchedAt: new Date().toISOString() }),
  ];

  const result = await client.query(query, values);
  return result.rows[0];
}

// -----------------------------------------------------------------------------
// jGrants fetcher（sync-jgrants.mjs と同等のロジックを埋め込み版で保持）
// -----------------------------------------------------------------------------
function extractItems(payload) {
  if (!payload) return [];
  if (Array.isArray(payload?.result)) return payload.result;
  if (Array.isArray(payload?.result?.items)) return payload.result.items;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

const resolveExternalId = (g) =>
  g?.id ?? g?.subsidyId ?? g?.subsidy_id ?? g?.jgrantsId ?? g?.jgrants_id ?? null;
const resolveName = (g) => g?.title ?? "不明";
const resolveDescription = (g) =>
  g?.summary ?? g?.outline ?? g?.description ?? null;
const resolveDeadlineRaw = (g) => g?.acceptance_end_datetime ?? null;

function resolveMaxAmountLabel(g) {
  const n = Number(g?.subsidy_max_limit);
  if (Number.isFinite(n) && n > 0) return `最大${n.toLocaleString("ja-JP")}円`;
  return null;
}

// jGrants API の一覧/検索エンドポイントは業種フィールドを返さないため、
// name/description からキーワードで推定してタグ付けする（一覧ページの絞り込みに必要）。
const INDUSTRY_KEYWORD_RULES = [
  { label: "農林水産業", keywords: ["農業", "林業", "漁業", "水産", "畜産", "農園", "農地", "酪農"] },
  { label: "製造業", keywords: ["製造業", "製造", "工場", "ものづくり", "モノづくり", "生産設備", "金属加工", "食品加工", "町工場"] },
  { label: "建設業", keywords: ["建設業", "建設", "建築", "土木", "解体工事", "リフォーム", "住宅工事", "工事業"] },
  { label: "物流・運輸", keywords: ["物流", "運輸業", "運送業", "倉庫業", "トラック運送", "配送業"] },
  { label: "IT・情報通信", keywords: ["IT導入", "情報通信業", "ソフトウェア", "システム開発", "デジタル化", "情報サービス業", "アプリ開発"] },
  { label: "小売・サービス業", keywords: ["小売業", "商店街", "商店", "小売店", "サービス業", "卸売業", "EC事業", "美容業"] },
  { label: "医療・福祉", keywords: ["医療機関", "病院", "診療所", "クリニック", "介護", "福祉施設", "薬局", "訪問看護"] },
  { label: "飲食業", keywords: ["飲食店", "飲食業", "レストラン", "居酒屋", "カフェ", "食堂"] },
  { label: "観光・宿泊", keywords: ["観光", "宿泊業", "ホテル", "旅館", "民泊", "旅行業"] },
];
const BROAD_INDUSTRY_KEYWORDS = ["中小企業全般", "業種を問わず", "全業種", "全ての事業者", "すべての事業者", "業種問わず"];

function inferIndustriesFromText(text) {
  if (!text) return [];
  const matched = new Set();
  for (const rule of INDUSTRY_KEYWORD_RULES) {
    if (rule.keywords.some((k) => text.includes(k))) matched.add(rule.label);
  }
  if (matched.size === 0 && BROAD_INDUSTRY_KEYWORDS.some((k) => text.includes(k))) {
    matched.add("全業種");
  }
  return [...matched];
}

function resolveTargetIndustries(g) {
  const c =
    g?.targetIndustries ??
    g?.target_industries ??
    g?.industries ??
    g?.targetIndustry;
  if (Array.isArray(c)) {
    const explicit = c.map((v) => String(v).trim()).filter((v) => v);
    if (explicit.length > 0) return explicit;
  }
  if (typeof c === "string" && c.trim()) return [c.trim()];
  const text = [resolveName(g), resolveDescription(g), g?.institution_name]
    .filter((v) => typeof v === "string" && v.trim())
    .join(" ");
  return inferIndustriesFromText(text);
}

function parseDeadline(raw) {
  if (!raw) return null;
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? null : d;
}

async function fetchAllOpenGrants(userAgent) {
  const results = [];
  const seen = new Set();
  let offset = 0;
  const limit = 100;
  let prevSig = null;
  const MAX_LOOPS = 200;
  let loops = 0;

  while (true) {
    loops += 1;
    if (loops > MAX_LOOPS) break;

    const params = new URLSearchParams({
      keyword: "補助金",
      sort: "created_date",
      order: "DESC",
      acceptance: "1",
      limit: String(limit),
      offset: String(offset),
    });
    const res = await fetch(`${JGRANTS_BASE}/subsidies?${params.toString()}`, {
      headers: {
        Accept: "application/json",
        "User-Agent": userAgent,
      },
    });
    if (!res.ok) {
      throw new Error(`jGrants API error: ${res.status} ${res.statusText}`);
    }
    const payload = await res.json();
    const items = extractItems(payload);
    const sig = `${items.length}:${items
      .map((i) => resolveExternalId(i) ?? "")
      .join("|")}`;
    if (sig === prevSig) break;
    prevSig = sig;

    let added = 0;
    for (const it of items) {
      const id = resolveExternalId(it) ?? `${resolveName(it)}::x`;
      if (seen.has(id)) continue;
      seen.add(id);
      results.push(it);
      added += 1;
    }
    if (items.length === 0 || added === 0 || items.length < limit) break;
    offset += limit;
    await new Promise((r) => setTimeout(r, 100));
  }
  return results;
}

function filterOpen(grants) {
  const now = new Date();
  return grants.filter((g) => {
    const d = parseDeadline(resolveDeadlineRaw(g));
    if (d && d < now) return false;
    return true;
  });
}

/** 2050年より先の期限は jGrants のデータ不備とみなし null に補正 */
const DEADLINE_SANITY_MAX = new Date("2050-01-01");

/** rawPayload.target_area_search から都道府県を抽出。"全国" は null */
function resolvePrefecture(grant) {
  const area = grant?.target_area_search ?? null;
  if (!area || area.trim() === "全国" || area.trim() === "") return null;
  return area.trim();
}

async function upsertGrant(client, grant) {
  const externalId = resolveExternalId(grant);
  const name = resolveName(grant);
  const description = resolveDescription(grant);
  const maxAmountLabel = resolveMaxAmountLabel(grant);
  const deadlineRaw = resolveDeadlineRaw(grant);
  const deadlineRaw2 = parseDeadline(deadlineRaw);
  // 2050年超えは異常値として null に補正
  const deadline =
    deadlineRaw2 && deadlineRaw2 > DEADLINE_SANITY_MAX ? null : deadlineRaw2;
  const targetIndustries = resolveTargetIndustries(grant);
  const targetIndustryNote = grant?.target_area_search ?? null;
  const prefecture = resolvePrefecture(grant);

  const query = `
    INSERT INTO "SubsidyGrant" (
      id, "externalId", name, description,
      "maxAmountLabel", "deadlineLabel",
      deadline, status, source,
      "targetIndustries", "targetIndustryNote", prefecture, "rawPayload", "updatedAt", "syncedAt"
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7,'open','jgrants',$8,$9,$10,$11::jsonb,NOW(),NOW())
    ON CONFLICT ("externalId") DO UPDATE SET
      name = EXCLUDED.name,
      description = EXCLUDED.description,
      "maxAmountLabel" = EXCLUDED."maxAmountLabel",
      "deadlineLabel" = EXCLUDED."deadlineLabel",
      deadline = EXCLUDED.deadline,
      "targetIndustries" = EXCLUDED."targetIndustries",
      "targetIndustryNote" = EXCLUDED."targetIndustryNote",
      prefecture = EXCLUDED.prefecture,
      "rawPayload" = EXCLUDED."rawPayload",
      source = 'jgrants',
      status = 'open',
      "updatedAt" = NOW()
    RETURNING id, (xmax = 0) AS is_new
  `;
  const values = [
    randomUUID(),
    externalId,
    name,
    description,
    maxAmountLabel,
    deadlineRaw ? String(deadlineRaw) : null,
    deadline,
    targetIndustries,
    targetIndustryNote,
    prefecture,
    JSON.stringify(grant),
  ];
  const result = await client.query(query, values);
  return result.rows[0];
}

async function enqueueArticleJob(client, subsidyId) {
  await client.query(
    `
    INSERT INTO content_jobs (id, subsidy_id, job_type, status, triggered_at)
    VALUES ($1, $2, 'article', 'pending', NOW())
    ON CONFLICT (subsidy_id, job_type) DO NOTHING
    `,
    [randomUUID(), subsidyId],
  );
}

/** LP コピー生成ジョブをキューイングする（contentType="lp"） */
async function enqueueLpJob(client, subsidyId) {
  await client.query(
    `
    INSERT INTO content_jobs (id, subsidy_id, job_type, status, triggered_at)
    VALUES ($1, $2, 'lp', 'pending', NOW())
    ON CONFLICT (subsidy_id, job_type) DO NOTHING
    `,
    [randomUUID(), subsidyId],
  );
}

/** 記事が published になった補助金に対して video ジョブをキューイングする */
async function enqueueVideoJob(client, subsidyId) {
  await client.query(
    `
    INSERT INTO content_jobs (id, subsidy_id, job_type, status, triggered_at)
    VALUES ($1, $2, 'video', 'pending', NOW())
    ON CONFLICT (subsidy_id, job_type) DO NOTHING
    `,
    [randomUUID(), subsidyId],
  );
}

async function selectPendingJobs(client, limit) {
  const res = await client.query(
    `
    SELECT subsidy_id
    FROM content_jobs
    WHERE job_type = 'article' AND status = 'pending'
    ORDER BY triggered_at ASC
    LIMIT $1
    `,
    [limit],
  );
  return res.rows.map((r) => r.subsidy_id);
}

async function selectPendingLpJobs(client, limit) {
  const res = await client.query(
    `
    SELECT subsidy_id
    FROM content_jobs
    WHERE job_type = 'lp' AND status = 'pending'
    ORDER BY triggered_at ASC
    LIMIT $1
    `,
    [limit],
  );
  return res.rows.map((r) => r.subsidy_id);
}

async function selectPendingVideoJobs(client, limit) {
  const res = await client.query(
    `
    SELECT subsidy_id
    FROM content_jobs
    WHERE job_type = 'video' AND status = 'pending'
    ORDER BY triggered_at ASC
    LIMIT $1
    `,
    [limit],
  );
  return res.rows.map((r) => r.subsidy_id);
}

// -----------------------------------------------------------------------------
// Vercel API 呼び出し
// -----------------------------------------------------------------------------
async function callGenerate({ vercelUrl, token, subsidyId }) {
  const res = await fetch(`${vercelUrl}/api/articles/generate`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-internal-token": token,
    },
    body: JSON.stringify({ subsidyId }),
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { ok: false, error: text.slice(0, 200) };
  }
  return { httpStatus: res.status, ...json };
}

async function callGenerateLp({ vercelUrl, token, subsidyId }) {
  const res = await fetch(`${vercelUrl}/api/lp/generate`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-internal-token": token,
    },
    body: JSON.stringify({ subsidyId }),
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { ok: false, error: text.slice(0, 200) };
  }
  return { httpStatus: res.status, ...json };
}

async function callGenerateVideo({ vercelUrl, token, subsidyId }) {
  const res = await fetch(`${vercelUrl}/api/videos/generate`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-internal-token": token,
    },
    body: JSON.stringify({ subsidyId }),
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { ok: false, error: text.slice(0, 200) };
  }
  return { httpStatus: res.status, ...json };
}

async function callRevalidate({ vercelUrl, secret, slugs }) {
  const res = await fetch(`${vercelUrl}/api/revalidate`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-internal-token": secret,
    },
    body: JSON.stringify({ slugs }),
  });
  const text = await res.text();
  try {
    return { httpStatus: res.status, ...JSON.parse(text) };
  } catch {
    return { httpStatus: res.status, ok: false, error: text.slice(0, 200) };
  }
}

// -----------------------------------------------------------------------------
// Lambda handler
// -----------------------------------------------------------------------------
export async function handler(event = {}) {
  const startedAt = Date.now();
  const DATABASE_URL = process.env.DATABASE_URL;
  const VERCEL_APP_URL = (process.env.VERCEL_APP_URL ?? "").replace(/\/$/, "");
  const ARTICLE_GENERATE_TOKEN = process.env.ARTICLE_GENERATE_TOKEN;
  const REVALIDATE_SECRET = process.env.REVALIDATE_SECRET;
  const DRAIN_LIMIT_LEGACY = Number(process.env.DRAIN_LIMIT ?? NaN);
  const DRAIN_LIMIT_ARTICLE = Number(
    process.env.DRAIN_LIMIT_ARTICLE ??
      (Number.isFinite(DRAIN_LIMIT_LEGACY) ? DRAIN_LIMIT_LEGACY : 1),
  ) || 0;
  const DRAIN_LIMIT_LP = Number(
    process.env.DRAIN_LIMIT_LP ??
      (Number.isFinite(DRAIN_LIMIT_LEGACY) ? DRAIN_LIMIT_LEGACY : 1),
  ) || 0;
  const DRAIN_LIMIT_VIDEO = Number(
    process.env.DRAIN_LIMIT_VIDEO ??
      (Number.isFinite(DRAIN_LIMIT_LEGACY) ? DRAIN_LIMIT_LEGACY : 0),
  ) || 0;
  const ENABLE_VERCEL_VIDEO =
    process.env.ENABLE_VERCEL_VIDEO === "true" ||
    process.env.ENABLE_VERCEL_VIDEO === "1";
  const SYNC_USER_AGENT =
    process.env.SYNC_USER_AGENT ?? "nts-gate-lp-sync/1.0";

  if (!DATABASE_URL) throw new Error("DATABASE_URL is required");
  if (!VERCEL_APP_URL) throw new Error("VERCEL_APP_URL is required");
  if (!ARTICLE_GENERATE_TOKEN)
    throw new Error("ARTICLE_GENERATE_TOKEN is required");
  if (!REVALIDATE_SECRET) throw new Error("REVALIDATE_SECRET is required");

  const { Client } = pg;
  const client = new Client({
    connectionString: DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  const report = {
    ok: true,
    event,
    ministry: { fetched: 0, newGrants: 0, errors: [] },
    sync: { fetched: 0, newGrants: 0, updatedGrants: 0 },
    generate: { picked: 0, published: 0, rejected: 0, failed: 0, details: [] },
    lp: { picked: 0, published: 0, failed: 0, details: [] },
    video: { picked: 0, published: 0, script_only: 0, failed: 0, details: [] },
    revalidate: null,
    elapsedMs: 0,
  };

  try {
    await client.connect();

    // ----- 0) 省庁クローラー（RSS + HTML）-----
    // 各ソースから最新 MINISTRY_FETCH_LIMIT 件を取得し、新規のみ記事ジョブをキューイングする。
    // 差分検知は externalId の ON CONFLICT で自動処理される。
    const ministrySources = [
      // 経済産業省 報道発表 Atom フィード
      { type: "rss",  url: "https://www.meti.go.jp/ml_index_release_atom.xml",                            source: "meti" },
      // ミラサポ plus（中小企業庁系）補助金カテゴリ RSS
      { type: "rss",  url: "https://mirasapo-plus.go.jp/category/infomation/subsidy/feed/",               source: "chusho" },
      // 農林水産省 補助事業公募一覧（HTML）
      { type: "html", url: "https://www.maff.go.jp/j/supply/hozyo/index.html", base: "https://www.maff.go.jp", source: "maff" },
      // 国土交通省 報道発表資料（HTML）
      { type: "html", url: "https://www.mlit.go.jp/report/press/index.html",   base: "https://www.mlit.go.jp", source: "mlit" },
    ];

    report.ministry = { fetched: 0, newGrants: 0, errors: [] };

    for (const src of ministrySources) {
      try {
        let items = [];
        if (src.type === "rss") {
          items = await fetchRssItems(src.url, SYNC_USER_AGENT);
          items = items.filter((i) => isSubsidyRelated(i.title));
        } else {
          items = await fetchHtmlLinks(src.url, src.base, SYNC_USER_AGENT);
        }

        report.ministry.fetched += items.length;
        console.log(`${LOG} ministry[${src.source}] fetched=${items.length}`);

        for (const item of items) {
          const row = await upsertMinistryGrant(client, { ...item, source: src.source });
          if (row?.is_new) {
            report.ministry.newGrants += 1;
            await enqueueArticleJob(client, row.id);
          }
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        console.warn(`${LOG} ministry[${src.source}] ERROR: ${msg}`);
        report.ministry.errors.push({ source: src.source, error: msg });
        // 省庁クローラーの失敗はパイプライン全体を止めない
      }
    }
    console.log(`${LOG} ministry done fetched=${report.ministry.fetched} new=${report.ministry.newGrants}`);

    // ----- 1) sync -----
    const allGrants = await fetchAllOpenGrants(SYNC_USER_AGENT);
    const filtered = filterOpen(allGrants);
    report.sync.fetched = filtered.length;

    for (const g of filtered) {
      const row = await upsertGrant(client, g);
      if (row.is_new) {
        report.sync.newGrants += 1;
        await enqueueArticleJob(client, row.id);
      } else {
        report.sync.updatedGrants += 1;
      }
    }
    console.log(`${LOG} synced new=${report.sync.newGrants} updated=${report.sync.updatedGrants}`);

    // ----- 2) drain pending jobs -----
    const pendingIds = await selectPendingJobs(client, DRAIN_LIMIT_ARTICLE);
    report.generate.picked = pendingIds.length;
    const publishedSlugs = [];

    for (const subsidyId of pendingIds) {
      try {
        const result = await callGenerate({
          vercelUrl: VERCEL_APP_URL,
          token: ARTICLE_GENERATE_TOKEN,
          subsidyId,
        });
        if (result.httpStatus >= 200 && result.httpStatus < 300 && result.ok) {
          if (result.status === "published") {
            report.generate.published += 1;
            if (result.slug) publishedSlugs.push(result.slug);
            // 記事が公開されたら LP コピー生成ジョブと動画ジョブも積む
            await enqueueLpJob(client, subsidyId);
            await enqueueVideoJob(client, subsidyId);
          } else {
            report.generate.rejected += 1;
          }
          report.generate.details.push({
            subsidyId,
            status: result.status,
            slug: result.slug ?? null,
            violations: result.violations ?? [],
          });
        } else {
          report.generate.failed += 1;
          report.generate.details.push({
            subsidyId,
            status: "http-failed",
            httpStatus: result.httpStatus,
            error: result.error ?? "",
          });
        }
      } catch (e) {
        report.generate.failed += 1;
        report.generate.details.push({
          subsidyId,
          status: "exception",
          error: e instanceof Error ? e.message : String(e),
        });
      }
    }
    console.log(
      `${LOG} generated published=${report.generate.published} rejected=${report.generate.rejected} failed=${report.generate.failed}`,
    );

    // ----- 2b) drain pending LP jobs -----
    // 記事生成の次の実行サイクル（15分後）に LP コピーを生成する。
    // 同一実行内でも pending があれば処理する（再実行・バックフィル対応）。
    const pendingLpIds = await selectPendingLpJobs(client, DRAIN_LIMIT_LP);
    report.lp.picked = pendingLpIds.length;

    for (const subsidyId of pendingLpIds) {
      try {
        const result = await callGenerateLp({
          vercelUrl: VERCEL_APP_URL,
          token: ARTICLE_GENERATE_TOKEN,
          subsidyId,
        });
        if (result.httpStatus >= 200 && result.httpStatus < 300 && result.ok) {
          report.lp.published += 1;
          report.lp.details.push({ subsidyId, status: result.status, url: result.url ?? null });
        } else {
          report.lp.failed += 1;
          report.lp.details.push({ subsidyId, status: "http-failed", httpStatus: result.httpStatus, error: result.error ?? "" });
        }
      } catch (e) {
        report.lp.failed += 1;
        report.lp.details.push({ subsidyId, status: "exception", error: e instanceof Error ? e.message : String(e) });
      }
    }
    console.log(`${LOG} lp published=${report.lp.published} failed=${report.lp.failed}`);

    // ----- 2c) drain pending video jobs -----
    // 動画は FFmpeg 負荷が大きいため Vercel ではなくローカル CLI / 将来 Lambda で処理する。
    // ENABLE_VERCEL_VIDEO=true かつ DRAIN_LIMIT_VIDEO>0 のときのみ Vercel API を呼ぶ。
    let pendingVideoIds = [];
    if (ENABLE_VERCEL_VIDEO && DRAIN_LIMIT_VIDEO > 0) {
      pendingVideoIds = await selectPendingVideoJobs(client, DRAIN_LIMIT_VIDEO);
    } else {
      console.log(
        `${LOG} video skipped (ENABLE_VERCEL_VIDEO=${ENABLE_VERCEL_VIDEO}, DRAIN_LIMIT_VIDEO=${DRAIN_LIMIT_VIDEO}) — use scripts/drain-pending-videos.ts locally`,
      );
    }
    report.video.picked = pendingVideoIds.length;
    const publishedVideoSlugs = [];

    for (const subsidyId of pendingVideoIds) {
      try {
        const result = await callGenerateVideo({
          vercelUrl: VERCEL_APP_URL,
          token: ARTICLE_GENERATE_TOKEN,
          subsidyId,
        });
        if (result.httpStatus >= 200 && result.httpStatus < 300 && result.ok) {
          if (result.status === "published" || result.status === "audio_only") {
            report.video.published += 1;
            if (result.slug) publishedVideoSlugs.push(result.slug);
          } else {
            report.video.script_only += 1;
          }
          report.video.details.push({
            subsidyId,
            status: result.status,
            slug: result.slug ?? null,
          });
        } else {
          report.video.failed += 1;
          report.video.details.push({
            subsidyId,
            status: "http-failed",
            httpStatus: result.httpStatus,
            error: result.error ?? "",
          });
        }
      } catch (e) {
        report.video.failed += 1;
        report.video.details.push({
          subsidyId,
          status: "exception",
          error: e instanceof Error ? e.message : String(e),
        });
      }
    }
    console.log(
      `${LOG} video published=${report.video.published} script_only=${report.video.script_only} failed=${report.video.failed}`,
    );

    // 動画スラッグも revalidate 対象に追加
    for (const slug of publishedVideoSlugs) {
      publishedSlugs.push(slug);
    }

    // ----- 3) revalidate（公開した分だけ即時パージ） -----
    if (publishedSlugs.length > 0) {
      report.revalidate = await callRevalidate({
        vercelUrl: VERCEL_APP_URL,
        secret: REVALIDATE_SECRET,
        slugs: publishedSlugs,
      });
      console.log(
        `${LOG} revalidated slugs=${publishedSlugs.join(",")} ok=${report.revalidate.ok}`,
      );
    }

    // ----- 4) sync_logs 記録 -----
    await client.query(
      `
      INSERT INTO sync_logs (id, synced_at, records_fetched, records_upserted, error_message)
      VALUES ($1, NOW(), $2, $3, NULL)
      `,
      [
        randomUUID(),
        report.sync.fetched,
        report.sync.newGrants + report.sync.updatedGrants,
      ],
    );
  } catch (e) {
    report.ok = false;
    report.error = e instanceof Error ? e.message : String(e);
    console.error(`${LOG} FAILED`, e);
    try {
      await client.query(
        `
        INSERT INTO sync_logs (id, synced_at, records_fetched, records_upserted, error_message)
        VALUES ($1, NOW(), $2, $3, $4)
        `,
        [
          randomUUID(),
          report.sync.fetched,
          report.sync.newGrants + report.sync.updatedGrants,
          report.error,
        ],
      );
    } catch {
      // ignore
    }
    throw e; // Lambda 側にも失敗を伝播（EventBridge のエラーメトリクスに載る）
  } finally {
    report.elapsedMs = Date.now() - startedAt;
    await client.end().catch(() => {});
    console.log(`${LOG} report`, JSON.stringify(report));
  }

  return report;
}

// ローカル動作確認用（Node から直接 `node lambda/article-pipeline/index.mjs` で呼べる）
// Windows / Linux 両対応のため fileURLToPath で比較
import { fileURLToPath } from "node:url";
const isDirectInvocation = (() => {
  // Lambda 環境では AWS_LAMBDA_FUNCTION_NAME が必ず設定されるため、
  // その場合は絶対にローカル起動扱いにしない。
  if (process.env.AWS_LAMBDA_FUNCTION_NAME) return false;
  try {
    const selfPath = fileURLToPath(import.meta.url);
    const argvPath = process.argv[1] ?? "";
    return selfPath === argvPath;
  } catch {
    return false;
  }
})();

if (isDirectInvocation) {
  (async () => {
    const dotenv = await import("dotenv");
    const path = await import("node:path");
    dotenv.default.config({ path: path.resolve(process.cwd(), ".env.local") });
    dotenv.default.config({ path: path.resolve(process.cwd(), ".env") });

    try {
      const r = await handler({ source: "local" });
      console.log(JSON.stringify(r, null, 2));
      process.exit(0);
    } catch (e) {
      console.error(e);
      process.exit(1);
    }
  })();
}
